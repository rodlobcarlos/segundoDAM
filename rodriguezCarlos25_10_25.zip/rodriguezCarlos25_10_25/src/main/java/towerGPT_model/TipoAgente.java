package towerGPT_model;

public enum TipoAgente {

	HUMANO, IA
}
