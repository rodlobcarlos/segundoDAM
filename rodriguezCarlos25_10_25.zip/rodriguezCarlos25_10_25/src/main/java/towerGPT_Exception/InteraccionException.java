package towerGPT_Exception;

public class InteraccionException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InteraccionException(String mensaje) {
		super(mensaje);
	}
}
