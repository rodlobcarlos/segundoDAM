# Hola Mundo PyPI

Ejemplo de empaquetado y distribución de una aplicación Python.