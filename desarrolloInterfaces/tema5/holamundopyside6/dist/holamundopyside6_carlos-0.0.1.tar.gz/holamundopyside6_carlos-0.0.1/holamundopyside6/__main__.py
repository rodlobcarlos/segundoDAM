def main():
    print("Empaquetado y distribucion en PyPi")

if __name__ == "__main__":
    main()