package android.ejemplo.examencarlosrodriguez;

public class Datos {
    private String texto1;
    private String texto2;
    public Datos(String texto1, String texto2){
        this.texto1 = texto1;
        this.texto2 = texto2;
    }
    public String getTexto1(){
        return texto1;
    }
    public String getTexto2(){
        return texto2;
    }

    @Override
    public String toString() {
        return "Datos{" +
                "texto1='" + texto1 + '\'' +
                ", texto2='" + texto2 + '\'' +
                '}';
    }
}
