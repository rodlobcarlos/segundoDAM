package modelBancoAlimento;

public enum TipoPersonal {

	ASALARIADO, VOLUNTARIO
}
