package exceptionBancoAlimento;

public class BancoException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BancoException(String mensaje) {
		super(mensaje);
	}
}
