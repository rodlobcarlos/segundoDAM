package dao;

import rodriguezCarlosParte1Hibernate_modelo.Pelicula;
import util.AbstractDao;

public class PeliculaDao extends AbstractDao<Pelicula> {

	public PeliculaDao() {
		setClase(Pelicula.class);
	}

}
