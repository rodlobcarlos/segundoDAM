package dao;

import rodriguezCarlosParte1Hibernate_modelo.Cine;
import util.AbstractDao;

public class CineDao extends AbstractDao<Cine> {

	public CineDao() {
		setClase(Cine.class);
	}

}
