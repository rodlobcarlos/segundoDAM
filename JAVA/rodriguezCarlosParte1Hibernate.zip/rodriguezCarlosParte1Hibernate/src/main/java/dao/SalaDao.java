package dao;

import rodriguezCarlosParte1Hibernate_modelo.Sala;
import util.AbstractDao;

public class SalaDao extends AbstractDao<Sala> {

	public SalaDao() {
		setClase(Sala.class);
	}

}
