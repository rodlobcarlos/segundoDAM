package rodriguez_CarlosUD2;

public enum Candidato {

	ANA, BORJA, CARLA
}
