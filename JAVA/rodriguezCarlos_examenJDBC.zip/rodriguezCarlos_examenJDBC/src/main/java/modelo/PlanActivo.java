package modelo;

public enum PlanActivo {
	FREE, MENSUAL, TRIMESTRAL, ANUAL, VIP
}
