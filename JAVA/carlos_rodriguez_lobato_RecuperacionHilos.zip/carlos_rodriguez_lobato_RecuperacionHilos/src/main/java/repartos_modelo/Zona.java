package repartos_modelo;

public enum Zona {

	ZONA1, ZONA2
}
