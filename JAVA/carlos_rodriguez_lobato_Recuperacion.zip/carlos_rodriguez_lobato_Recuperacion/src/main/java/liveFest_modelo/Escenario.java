package liveFest_modelo;

// --- Clase ---
public enum Escenario {

	PRINCIPAL, SECUNDARIO, ALTERNATIVO
}
