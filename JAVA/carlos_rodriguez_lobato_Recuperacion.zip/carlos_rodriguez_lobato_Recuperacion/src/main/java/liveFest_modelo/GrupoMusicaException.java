package liveFest_modelo;

// --- Clase ---
public class GrupoMusicaException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// --- Constructor con mensaje ---
	public GrupoMusicaException(String mensaje) {
		super(mensaje);
	}

}
