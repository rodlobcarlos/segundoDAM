package enumDAM_ArenaMasters;

public enum TipoJuego {

	LOL, VALORANT, CSGO
}
