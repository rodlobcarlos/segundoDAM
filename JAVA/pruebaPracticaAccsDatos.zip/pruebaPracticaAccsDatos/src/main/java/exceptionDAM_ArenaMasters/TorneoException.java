package exceptionDAM_ArenaMasters;

public class TorneoException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TorneoException(String mensaje) {
		super(mensaje);
	}
}
