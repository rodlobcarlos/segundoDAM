package evaluable;

public enum PlanActivo {
	FREE, MENSUAL, TRIMESTRAL, ANUAL, VIP
}
