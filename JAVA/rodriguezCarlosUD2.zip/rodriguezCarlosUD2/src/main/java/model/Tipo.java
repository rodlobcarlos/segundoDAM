package model;

public enum Tipo {

	EDF, EPP
}
